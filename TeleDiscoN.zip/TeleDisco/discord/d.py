#!/usr/bin/env python
import sys
sys.path.append('..')
import discord
import asyncio
from r import Rmq

import logging
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)
fh = logging.FileHandler('bot.log')
fh.setLevel(logging.DEBUG)
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
fh.setFormatter(formatter)
logger.addHandler(fh)


client = discord.Client()

async def check_rabbit(rmq):
    await client.wait_until_ready()
    channel = discord.Object(id='286317575913340928')
    while not client.is_closed:
        msg = rmq.receive('todiscord')
        if msg is not None:
            await client.send_message(channel, msg.decode('utf-8','ignore'))
        await asyncio.sleep(1) # task runs every second

@client.event
async def on_ready():
    logger.info('Logged in as')
    logger.info(client.user.name + ' :: ' + client.user.id)

@client.event
async def on_message(message):
    if message.content.startswith('!test'):
        counter = 0
        tmp = await client.send_message(message.channel, 'Calculating messages...')
        async for log in client.logs_from(message.channel, limit=100):
            if log.author == message.author:
                counter += 1
        await client.edit_message(tmp, 'You have {} messages.'.format(counter))
    elif message.content.startswith('!LFP'):
        await client.send_message(message.channel, 'Not Implemented')
    elif message.content:
        if message.author.name != 'twctelegrambot':
            rmq.send('totelegram', str(message.author.name + ': ' + message.content))

@client.event
async def on_voice_state_update(before, after):
    if after.voice_channel == before.voice_channel:
        return
    elif after.voice_channel is None:
        message = after.name + ' has left'
    else:
        message = after.name + ' joined ' + (str(after.voice_channel) if after.voice_channel else '') + (' and is playing ' + after.game.name if after.game else '')
    rmq.send('totelegram', message)
    await client.send_message(discord.Object(id='286317575913340928'), message)

rmq = Rmq('rabbitmq')
client.loop.create_task(check_rabbit(rmq))
client.run('MzI0NzQ5ODE2ODU5MTk3NDQx.DCOOjg.WZ9Vb334shNauh7KKN1qbx2W3DI')
