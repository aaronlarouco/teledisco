#!/usr/bin/env python
import pika

class Rmq(object):

    def __init__(self, hostname):
        self.connection = pika.BlockingConnection(pika.ConnectionParameters(host=hostname))
        self.channel = self.connection.channel()

    def send(self, queue, message):
        self.channel.queue_declare(queue=queue)
        self.channel.basic_publish(exchange='',
                        routing_key=queue,
                        body=message)

    def receive(self, queue):
        self.channel.queue_declare(queue=queue)
        method_frame, header_frame, body = self.channel.basic_get(queue=queue, no_ack=True)
        if not method_frame:
            return None
        return body

    def close(self):
        self.connection.close()
