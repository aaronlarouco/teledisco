#!/usr/bin/env python
import sys
sys.path.append('..')
import telegram
from telegram.error import NetworkError, Unauthorized
from time import sleep
from r import Rmq

import logging
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)
fh = logging.FileHandler('bot.log')
fh.setLevel(logging.DEBUG)
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
fh.setFormatter(formatter)
logger.addHandler(fh)

update_id = None

def getMessage(rmq):
    return rmq.receive('totelegram')


def run():
    global update_id
    # Telegram Bot Authorization Token
    bot = telegram.Bot('391409554:AAHCYW97vh0FavLkRfZHaoWtJsYkN1SNqfk')
    rmq = Rmq('rabbitmq')

    # get the first pending update_id, this is so we can skip over it in case
    # we get an "Unauthorized" exception.
    try:
        update_id = bot.get_updates()[0].update_id
    except IndexError:
        update_id = None

    while True:
        try:
            echo(bot, rmq)
            msg = getMessage(rmq)
            if msg is 'null' or msg is None:
                continue
            bot.send_message(-220571995,msg.decode('utf-8','ignore'))
        except NetworkError:
            sleep(1)
        except Unauthorized:
            # The user has removed or blocked the bot.
            update_id += 1


def echo(bot, rmq):
    global update_id
    # Request updates after the last update_id
    for update in bot.get_updates(offset=update_id):
        update_id = update.update_id + 1

        if update.message:  # bot can receive updates without messages
            # Reply to the message
            if update.message.text == '/who':
                # we can keep an active dir of who's in the discord and just parrot it here
                pass
            if (update.message.text is not None) and (update.message.text != 'None'):
                try:
                    if update.message.from_user.username != 'twcdiscordbot':
                        rmq.send('todiscord', str(update.message.from_user.first_name
                                                + ' ' + update.message.from_user.last_name
                                                + ': ' + update.message.text))
                except:
                    #literally couldn't pay me to care
                    pass
            #update.message.reply_text(update.message.text)



run()
