"# teledisco" 
