cd telegram
docker build -t telegram .
cd ../discord
docker build -t discord .

# remove old containers
docker rm discord telegram
# run rabbit and the bots
docker run -d --hostname rabbitmq --name rabbitmq rabbitmq:latest
docker run -d --link rabbitmq --name telegram telegram
docker run -d --link rabbitmq --name discord discord
